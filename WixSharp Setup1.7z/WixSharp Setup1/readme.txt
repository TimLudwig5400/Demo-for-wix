﻿This is Tims Readme file. 


READ IT!!!!!!!!!!!!!!!!!!!!!!!!!!!